import json
from flask import Flask, request, Response, render_template, flash, redirect, url_for, session, logging, send_from_directory
from functools import wraps
from io import StringIO
from itsdangerous import URLSafeTimedSerializer
import datetime
import time
from bson.objectid import ObjectId
import os
import re
from flask import Flask
from werkzeug.utils import secure_filename
import moviepy.editor as mp
import imageio
import cv2
from flask import send_file

app = Flask(__name__, static_url_path='/')

# UPLOAD_FOLDER = '/user_banners'
UPLOAD_FOLDER = '/home/bharat/Downloads/videoEditor/user_banners'
ALLOWED_EXTENSIONS = set(['.png', '.jpg', '.jpeg'])
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route("/upload_banner", methods = ["GET", "POST"])
def process_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            print('No file part')
            return redirect(request.url)
        file = request.files['file']

        videos = []
        videos_links = []

        videos_available = False
        for i in request.form:
            if 'video' in i:
                videos.append(i)
                videos_available = True

        if videos_available == False:
            return "No videos selected"


        print(videos)
                
        # if user does not select file, browser also
        # submit a empty part without filename
        if file.filename == '':
            print('No selected file')
            return redirect(request.url)

        filename, file_extension = os.path.splitext(file.filename)
        # print(file_extension)
        if file and file_extension in ALLOWED_EXTENSIONS:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'],filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'],filename))
            print(file, filename, filepath)
            # print("Uploaded")

        for v in videos:
            video = mp.VideoFileClip("/home/bharat/Downloads/videoEditor/videos/" + v + ".mp4").subclip(1, 10)
            duration = video.duration
            print(duration)

            width, height = video.size
            # width = 1280
            img_height = 150
            video.resize((width, height - 150)).margin(bottom=150, left=0, right=0,top=0)

            print(filename)

            img = cv2.imread('/home/bharat/Downloads/videoEditor/user_banners/' + filename)
            name, extention = os.path.splitext(filename)

            new_filename = name + "_" + v + extention

            resized_img = cv2.resize(img,(width,img_height))
            cv2.imwrite("/home/bharat/Downloads/videoEditor/user_banners/" + new_filename ,resized_img)
            # Make the text. Many more options are available.
            logo = (mp.ImageClip("/home/bharat/Downloads/videoEditor/user_banners/" + new_filename)
                    .set_duration(video.duration)
                    .resize(height=150)
                    #  .resize(width=400)
                    #  .margin(right=4, top=8, opacity=0) # (optional) logo-border padding 
                    .set_pos(("left","bottom"))) 
            final = mp.CompositeVideoClip([video, logo])

            video_banner_fp = "/home/bharat/Downloads/videoEditor/user_videos/" + new_filename.replace(extention, "") + ".mp4"
            final.write_videofile(video_banner_fp)
    
            videos_links . append(video_banner_fp)

        
        return '<br>'.join(videos_links)

if __name__ == '__main__':
	app.secret_key = 'mysecret'
	app.run(host= '0.0.0.0', port=8100,debug=True)